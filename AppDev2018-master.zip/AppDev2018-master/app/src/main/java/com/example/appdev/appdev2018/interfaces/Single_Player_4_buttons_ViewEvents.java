package com.example.appdev.appdev2018.interfaces;

/**
 * Created by aguatno on 3/16/18.
 */

public interface Single_Player_4_buttons_ViewEvents {
    void onFragmentSButton1Clicked(int whereIsCorrectAnswer);
    void onFragmentSButton2Clicked(int whereIsCorrectAnswer);
    void onFragmentSButton3Clicked(int whereIsCorrectAnswer);
    void onFragmentSButton4Clicked(int whereIsCorrectAnswer);
}
