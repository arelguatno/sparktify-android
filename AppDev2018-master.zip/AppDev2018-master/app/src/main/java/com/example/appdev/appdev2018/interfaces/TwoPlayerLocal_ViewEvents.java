package com.example.appdev.appdev2018.interfaces;

/**
 * Created by aguatno on 3/30/18.
 */

public interface TwoPlayerLocal_ViewEvents {
    void onback_press();
}
