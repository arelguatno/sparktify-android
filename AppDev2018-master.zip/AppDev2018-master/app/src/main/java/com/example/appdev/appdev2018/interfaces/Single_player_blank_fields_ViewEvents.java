package com.example.appdev.appdev2018.interfaces;

/**
 * Created by aguatno on 3/16/18.
 */

public interface Single_player_blank_fields_ViewEvents {
    void fieldText_anyButtonPress(boolean gotIt);
}
